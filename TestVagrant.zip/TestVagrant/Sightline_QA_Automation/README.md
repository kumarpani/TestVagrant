# Sightline
---------------------------------------------------------------------------------------------------
This project is a Test Automation Framework built using Maven, TestNG and selenium to validate SightLine functionalities.
This is a Page Object Model (POM) framework and below details brief about folder structure.
> src/main/java is a root folder under this we have following packages:
  1. automationLibrary - Contains main driver and element classes.
  2. configsAndTestData - Contains class and XML files of configMain, environments and test data.
  3. pageFactory - Each page of the application is mapped to specific class here. All locators and functions of the specific page are    	maintained in specific class.
  4. testScriptSmoke - contains classes where somke test scenarios are covered. We could see sepearte class based on module.
  5. testScriptsRegression- contains classes where regression scenarios are covered.

> src/test/java - just a place holder. Empty one!

Other folders in the project directory :
> BrowserDrivers - contains chrome, IE browser drivers which are used by selenium to communicate with respective browsers.
                   This folder also contains bat files to kill background process of the browsers post execution of scripts.

> Misc -  Gmail properties file to deal with emails validation, fetch an OTP and activation links.
          Also contains batch file to validate batch upload functionality.
	  
  
---------------------------------------------------------------------------------------------------
Plugins required in Eclipse :
1. TestNG -  To execute scripts and get automated report. 
2. Maven  - This is a Maven project so that building the project and getting all dependencies is made easy.
---------------------------------------------------------------------------------------------------
Project setup in Eclipse:

