package configsAndTestData;

public class TestData {
	//search 
		public String searchString1;
		public String searchString2;
		public int pureHitSeachString1;
		public int pureHitSeachString2;
		public int searchString1ANDsearchString2;
		public int searchString1ORsearchString2;
		public int searchString1NOTsearchString2;
		public int searchString2NOTsearchString1;
		public String audioSearchString1;
		public int audioSearchString1pureHit;
		public String  conceptualSearchString1;
		public int  conceptualSearchString1PureHit;
		public String  metaDataCN;
		public int  metaDataCNcount;
		public int totalNumberOfDocs;
		public int totalNumberOfDocsincludeadvoption;
		public String MasterPDF1location;
		public String MasterPDF2location;
		
		public String getMetaDataCN() {
			return metaDataCN;
		}
		public void setMetaDataCN(String metaDataCN) {
			this.metaDataCN = metaDataCN;
		}
		public int getMetaDataCNcount() {
			return metaDataCNcount;
		}
		public void setMetaDataCNcount(int metaDataCNcount) {
			this.metaDataCNcount = metaDataCNcount;
		}
		
		 
		
		public String getConceptualSearchString1() {
			return conceptualSearchString1;
		}
		public void setConceptualSearchString1(String conceptualSearchString1) {
			this.conceptualSearchString1 = conceptualSearchString1;
		}
		public int getConceptualSearchString1PureHit() {
			return conceptualSearchString1PureHit;
		}
		public void setConceptualSearchString1PureHit(int conceptualSearchString1PureHit) {
			this.conceptualSearchString1PureHit = conceptualSearchString1PureHit;
		}
		
		public String getAudioSearchString1() {
			return audioSearchString1;
		}
		public void setAudioSearchString1(String audioSearchString1) {
			this.audioSearchString1 = audioSearchString1;
		}
		public int getAudioSearchString1pureHit() {
			return audioSearchString1pureHit;
		}
		public void setAudioSearchString1pureHit(int audioSearchString1pureHit) {
			this.audioSearchString1pureHit = audioSearchString1pureHit;
		}
		

		 public String getSearchString1() {
			return searchString1;
		}
		public void setSearchString1(String searchString1) {
			this.searchString1 = searchString1;
		}
		public String getSearchString2() {
			return searchString2;
		}
		public void setSearchString2(String searchString2) {
			this.searchString2 = searchString2;
		}
		public int getPureHitSeachString1() {
			return pureHitSeachString1;
		}
		public void setPureHitSeachString1(int pureHitSeachString1) {
			this.pureHitSeachString1 = pureHitSeachString1;
		}
		public int getPureHitSeachString2() {
			return pureHitSeachString2;
		}
		public void setPureHitSeachString2(int pureHitSeachString2) {
			this.pureHitSeachString2 = pureHitSeachString2;
		}
		public int getSearchString1ANDsearchString2() {
			return searchString1ANDsearchString2;
		}
		public void setSearchString1ANDsearchString2(int searchString1ANDsearchString2) {
			this.searchString1ANDsearchString2 = searchString1ANDsearchString2;
		}
		public int getSearchString1ORsearchString2() {
			return searchString1ORsearchString2;
		}
		public void setSearchString1ORsearchString2(int searchString1ORsearchString2) {
			this.searchString1ORsearchString2 = searchString1ORsearchString2;
		}
		public int getSearchString1NOTsearchString2() {
			return searchString1NOTsearchString2;
		}
		public void setSearchString1NOTsearchString2(int searchString1NOTsearchString2) {
			this.searchString1NOTsearchString2 = searchString1NOTsearchString2;
		}
		public int getSearchString2NOTsearchString1() {
			return searchString2NOTsearchString1;
		}
		public void setSearchString2NOTsearchString1(int searchString2NOTsearchString1) {
			this.searchString2NOTsearchString1 = searchString2NOTsearchString1;
		}
		
		public int gettotalNumberOfDocsincludeadvoption() {
			return totalNumberOfDocsincludeadvoption;
		}
		public void settotalNumberOfDocsincludeadvoption(int totalNumberOfDocsincludeadvoption) {
			this.totalNumberOfDocsincludeadvoption = totalNumberOfDocsincludeadvoption;
		}
		
		 public String MasterPDF1location() {
				return MasterPDF1location;
			}
			public void MasterPDF1location(String MasterPDF1location) {
				this.MasterPDF1location = MasterPDF1location;
			}
			
		 public String MasterPDF2location() {
				return MasterPDF2location;
			}
		public void MasterPDF2location(String MasterPDF2location) {
				this.MasterPDF2location = MasterPDF2location;
				}

}
