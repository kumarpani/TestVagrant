/* Class Name :
 * Author : 
 * Detailed Description :
 * 
 * 
 * 
 * Date Created:
 * Last Modified:
 * Modified By:
 */
package testScriptsSmoke;


import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import automationLibrary.Driver;
import executionMaintenance.UtilityLog;
import pageFactory.BaseClass;
import pageFactory.LoginPage;
import pageFactory.Utility;

//Used For Report
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class loginLogout {
	 Driver driver;
	 LoginPage lp;
	 BaseClass bc;
	 
	 public ExtentHtmlReporter htmlReporter;
	 public ExtentReports extent;
	 public ExtentTest testExtent;
	
	@BeforeClass(alwaysRun = true)
	public void preConditions() throws InterruptedException, ParseException, IOException {
		System.out.println("******Execution started for "+this.getClass().getSimpleName()+"********");
		UtilityLog.info("******Execution started for " + this.getClass().getSimpleName() + "********");
		UtilityLog.info("Started Execution for prerequisite");
		
		Input in = new Input();
		in.loadEnvConfig();

		}
	
	@BeforeMethod(alwaysRun = true)
	public void beforeTestMethod(ITestResult result,Method testMethod) throws IOException {
		Reporter.setCurrentTestResult(result);
		System.out.println("------------------------------------------");
		System.out.println("Executing method :  " + testMethod.getName());
		UtilityLog.logBefore(testMethod.getName());
	}
	
	@BeforeTest
	 public void setExtent() {
	  // specify location of the report
	  htmlReporter = new ExtentHtmlReporter(System.getProperty("user.dir") + "/test-output/myReport.html");

	  htmlReporter.config().setDocumentTitle("Smoke Test Results"); // Tile of report
	  htmlReporter.config().setReportName("Release Candidate Build Smoke Test Result on XYZ Environment"); // Name of the report
	  htmlReporter.config().setTheme(Theme.DARK); // Report Theme DARK or Standard
	  
	  extent = new ExtentReports();
	  extent.attachReporter(htmlReporter);
	  
	  // Passing General information
	  extent.setSystemInfo("Host name", "localhost");
	  extent.setSystemInfo("Environemnt", "XYZ");
	  extent.setSystemInfo("Executor", "Srinivas");
	  extent.setSystemInfo("Browser", "Chrome");
	  extent.setSystemInfo("OS", "WIndows 10");
	 }
	
	/*
	 * Author :  
	 * Created date: 
	 * Modified date: 
	 * Modified by: 
	 * Description : As a PA user Login and Logout
	 * with operators
	 * Test Case ID: RPMX*******
	 */
	@Test
	public void LoginasProjectAdmin() {
		
		//Open browser
		driver = new Driver();
		
		// Set report details for the test case
		testExtent = extent.createTest("Simple Login Logout Test | Test User : " +Input.pa1userName + " Test Data : "+ Input.pa1userName + "Test Case ID : RPMXCON-54770");
		
		//Login as a PA	
    	lp=new LoginPage(driver);
    	
    	lp.loginToSightLine(Input.pa1userName, Input.pa1password);
       	
    	Assert.assertEquals("ExpectedActual", "ExpectedActual");
	}
	
	@AfterTest
	 public void endReport() {
	  
		extent.flush();
		
	 }
	
	@AfterMethod
	 public void tearDown(ITestResult result) throws IOException {
	  if (result.getStatus() == ITestResult.FAILURE) {
	   testExtent.log(Status.FAIL, "TEST CASE FAILED IS " + result.getName()); // to add name in extent report
	   testExtent.log(Status.FAIL, "TEST CASE FAILED IS " + result.getThrowable()); // to add error/exception in extent report
	  	   	
	   String screenshotPath1 = Utility.screenShot2(result);
	   System.out.println("------------------------------------------");
	   System.out.println(screenshotPath1);
	   testExtent.addScreenCaptureFromPath(screenshotPath1);// adding screen shot
	  } else if (result.getStatus() == ITestResult.SKIP) {
		testExtent.log(Status.SKIP, "Test Case SKIPPED IS " + result.getName());
	  }
	  else if (result.getStatus() == ITestResult.SUCCESS) {
		testExtent.log(Status.PASS, "Test Case PASSED IS " + result.getName());
	  }
	    
	} 
	
	@AfterClass(alwaysRun = true)
	public void close() {
		try {
			lp.logout();
			// lp.quitBrowser();
		} finally {
			lp.quitBrowser();
			lp.clearBrowserCache();
		}
	}
	
}

